#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
#=============================================================================
#  ProjectName: first-test
#     FileName: haha
#         Desc: 
#       Author: Administrator
#        Email: 136665323@qq.com
#     HomePage: dlmdlm.github.io
#       Create: 2018-09-07 13:49
#=============================================================================
"""
import unittest
import HTMLTestRunner
# from mock import mock
from demo import RunMain
# from mock_demo import mock_test


class TestMethod(unittest.TestCase):
    def setUp(self):
        self.run = RunMain()

    def test_01(self):
        url = "http://m.imooc.com/passport/user/login"
        data = {
            "username": "13177802129",
            "password": "lovehjd1995",
            "verify": "",
            "referer": "https://m.imooc.com",
            # "status": 10001
        }
        # mock_data = mock.Mock(return_value=data)
        # mock一个方法
        # self.run.run_main = mock_data

        # self.run.run_main = mock.Mock(return_value=data)
        # 调用mock_test（）方法，把模拟的方法名传进去，模拟的是self.run.run_main这个方法，再把其他需要的参数偶都放进去
        # 如果你有很多方法要mock的话，就可以这样写，调用mock_test方法，然后把方法名写进去，
        # res = mock_test(self.run.run_main, data, url, "post", data)
        res = self.run.run_main(url, "post", data)
        self.assertEqual(res["status"], 10001, u"测试成功")
        print "one"

    # @unittest.skip("test_02")
    def test_02(self):
        url = "http://m.imooc.com/passport/user/login"
        data = {
            "username": "13177802129",
            "password": "lovehjd1995",
            "verify": "",
            "referer": "https://m.imooc.com"
        }
        res = self.run.run_main(url, "post", data)
        self.assertEqual(res["status"], 100001, u"测试失败")
        print "two"


if __name__ == '__main__':
    filepath = "F:/study-python/first-test/report/htmlreport.html"
    fp = file(filepath, "wb")

    # 创建一个容器=放case的集合，命名为suite
    suite = unittest.TestSuite()
    # 创建好后，往容器里面添加testcase
    suite.addTests([TestMethod("test_02")])
    suite.addTests([TestMethod("test_01")])
    runner = HTMLTestRunner.HTMLTestRunner(stream=fp, verbosity=2, title="this is first report")
    runner.run(suite)
    fp.close()

# 添加好后，可以运行
# unittest.TextTestRunner().run(suite)
# unittest.main()
